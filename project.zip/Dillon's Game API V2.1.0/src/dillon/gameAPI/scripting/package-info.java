/**
 * This package contains all of the things for the API to support scripting with
 * javascript.
 */
/**
 * @author Dillon - Github dg092099
 *
 */
package dillon.gameAPI.scripting;