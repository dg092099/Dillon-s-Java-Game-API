/**
 * This mapping package contains the newest mapping system.
 */
/**
 * @author Dillon - Github dg092099
 * @since V2.0
 */
package dillon.gameAPI.mapping;