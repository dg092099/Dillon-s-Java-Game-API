/**
 * This package defines several utilities that help the API in several ways.
 */
/**
 * @author Dillon - Github dg092099
 *
 */
package dillon.gameAPI.utils;