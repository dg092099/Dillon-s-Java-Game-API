/**
 * This package contains all vital classes to run the game API.
 */
/**
 * @author Dillon - Github dg092099
 *
 */
package dillon.gameAPI.core;