/**
 * This package contains the Entity class, which is used in the game to define any player or npc.
 */
/**
 * @author Dillon - Github dg092099
 *
 */
package dillon.gameAPI.entity;