/**
 * This package contains the game api's resources.
 */
/**
 * @author Dillon - Github dg092099.github.io
 */
package dillon.gameAPI.res;