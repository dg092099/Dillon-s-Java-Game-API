/**
 * This is a security package for managing code and what it can do in the
 * engine.
 */
/**
 * @author Dillon - Github dg092099.github.io
 * @since V1.13
 */
package dillon.gameAPI.security;