/**
 * This package contains various error messages that may be encountered in the api.
 */
/**
 * @author Dillon - Github dg092099
 *
 */
package dillon.gameAPI.errors;