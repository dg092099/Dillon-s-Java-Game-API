/**
 * This package defines the game api server and protocols.
 */
/**
 * @author Dillon - Github dg092099
 *
 */
package dillon.gameAPI.networking;